from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

app = FastAPI()

# Dummy users
fake_users_db = {
    "john": {"username": "john", "password": "secret123"},
    "priya": {"username": "priya", "password": "pass456"},
}

class LoginRequest(BaseModel):
    username: str
    password: str

class LoginResponse(BaseModel):
    message: str

@app.post("/login", response_model=LoginResponse)
def login(request: LoginRequest):
    user = fake_users_db.get(request.username)
    if not user or user["password"] != request.password:
        raise HTTPException(status_code=401, detail="Invalid username or password")
    return {"message": f"Welcome {request.username}!"}
